import os
prefix_database = "/etc/astrolyze/database/"
