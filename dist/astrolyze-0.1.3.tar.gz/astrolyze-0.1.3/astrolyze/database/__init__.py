import os
USER = os.getenv("USER")

prefifx_database = "/home/{}/.astrolyze/database/".format(USER)
