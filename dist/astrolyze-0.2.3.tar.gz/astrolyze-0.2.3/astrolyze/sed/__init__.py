'''
This module handles SED creation and display with 
MapClass.
'''

from sed import *
