class Error(Exception):
    '''Base Error class.'''
    pass

class ConfigurationError(Exception):
    '''Base Error class for the oi_calibration program.'''
    pass
