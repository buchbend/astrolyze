import os
prefix_database = os.path.abspath(os.path.dirname(__file__)) + '/'
