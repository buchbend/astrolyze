
#__all__ = ["maptools", "mapclass"]

#from mapclass.mapClassMain import *
#from mapclass.mapClassFits import *
#from mapclass.mapClassGildas import *
#from mapclass.mapClassMiriad import *
#import maptools.mapTools as tools
