The Readme file should be written in reST so that the PyPi.
