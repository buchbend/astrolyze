#__all__ = ["main", "fits", "gildas", "stack", "tools"]
# TODO: Decide on how astrolyze is initated best.
from main import *
from fits import *
from gildas import *
from miriad import *
from stack import *
import tools as mtools
